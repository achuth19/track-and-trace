from django.contrib import admin
from . models import User,entity_list,product,serials,batch
admin.site.register(User)
admin.site.register(entity_list)
admin.site.register(product)
admin.site.register(serials)
admin.site.register(batch)
# Register your models here.
