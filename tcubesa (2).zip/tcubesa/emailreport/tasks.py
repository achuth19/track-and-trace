
from celery import Celery
from celery import shared_task
from django.core.mail import send_mail
import logging
from django.urls import reverse
from django.conf import settings
from datetime import datetime,date
from django.template.loader import render_to_string
from django.utils.html import strip_tags
logger = logging.getLogger(__name__)

@shared_task
def send_daily_reports_task():
    try:
        
        from .models import product,User,serials,entity_list
     
        users = User.objects.filter(is_created_product=True)

        
        for user in users:
            subject = "Daily Report for your Products"
            message = "Here is the daily report for your products:"
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [user.email]
            if user.is_subscribed == True:
                entities = entity_list.objects.filter(user_details=user)
                products = product.objects.filter(user_details=user)
                for prod in products:
                    serialss = serials.objects.filter(linked_product=prod)
                    total_serials = serialss.count()
                    serials_commissioned = serialss.filter(is_commissioned=True).count()
                    serials_packed = serialss.filter(is_packed=True).count()
                    serials_shipped = serialss.filter(is_shipped=True).count()
                    serials_decommissioned = total_serials - serials_commissioned

                    prod.totalserials = total_serials
                    prod.serialscommissioned = serials_commissioned
                    prod.serialspacked = serials_packed
                    prod.serialsshipped = serials_shipped
                    prod.serialsdecommissioned = serials_decommissioned
                    prod.save()
                email_content = render_to_string('emailreport/dailyreport.html', {'entities': entities, 'products': products})
                logger.info("Task execution successful")
                message = message+strip_tags(email_content)
                send_mail(subject, message, from_email, recipient_list, html_message=email_content,fail_silently=False)

    except Exception as e:
        logger.exception("Error in send_daily_reports_task: %s", e)
