# test_celery.py
